inlets = 9;
outlets = 2;

setinletassist(0,"generate table");
setinletassist(1,"num tests");
setinletassist(2,"min delta");
setinletassist(3,"max delta");
setinletassist(4,"wait time");
setinletassist(5,"probe time");
setinletassist(6,"m1FingerPos");
setinletassist(7,"m2FingerPos");
setinletassist(8,"stepSizeMM");

var numTests;
var minDelta;
var maxDelta;
var waitTime;
var probeTime;
var m1FingerPos;
var m2FingerPos;
var stepSizeMM;
var minMovement = 2;

var testTable;
var testStepsTable;
var responseCompareTable;

function msg_int(n){
	switch(inlet){
		case 1:
			numTests = n;
		break;
		case 4:
			waitTime = n;
		break;
		case 5:
			probeTime = n;
		break;
		case 6:
			m1FingerPos = n;
		break;
		case 7:
			m2FingerPos = n;
		break;	
	}	
}

function msg_float(f){
	switch(inlet){
		case 2:
			minDelta = f;
		break;
		case 3:
			maxDelta = f;
		break;
		case 8:
			stepSizeMM = f;
		break;
	}	
	
}

function bang(){
	if(inlet == 0){
		generateRandomTableData();
	}
}


function generateRandomTableData(){
	
	responseCompareTable = new Array();
	responseCompareTable.length = 0;
	
	testTable = new Array();
	testTable.length = 0;
	
	var numSmall = numTests/2;
	var numBig = numTests/2;
	//post("nums = " + numSmall + " " + numBig + "\n");
	
	for(var i=0; i<numTests; i++){
		testTable[i] = -1;
		if(i < 3){
			if(Math.random()*10 > 5){
				if(numSmall > 0){
					testTable[i] = 0;
					numSmall--;
				}
				else{
					testTable[i] = 1;
					numBig--;
				}	
			}
			else{
				if(numBig > 0){
					testTable[i] = 1;
					numBig--;
				}
				else{
					testTable[i] = 0;
					numSmall--;
				}
				
			}
				
		}
		else{
			
			var sum = 0;
			for(var j=1; j<4; j++){
				sum += testTable[i-j];
			}
			//post("sum = " + sum + "\n");
			if(sum == 0){
				if(numBig > 0){
					testTable[i] = 1;
					numBig--;
				}
			}
			else if(sum == 3){
				if(numSmall > 0){
					testTable[i] = 0;
					numSmall--;
				}
			}
			else{
				var rand = Math.floor(Math.random()*numTests);
				//post("rand = " + rand + " " + numBig + " " + numSmall + "\n");
				if(rand >= numBig){
					if(numSmall > 0){
						testTable[i] = 0;
						numSmall--;
					}
					else{
						testTable[i] = 1;
						numBig--;
					}	
				}
				else{
					if(numBig > 0){
						testTable[i] = 1;
						numBig--;
					}
				else{
						testTable[i] = 0;
						numSmall--;
					}
				
				}
				
			}
			
		}
		
		//post(testTable[i] + " ");
		//post("\n");
		
	}
	post("\n");
	var s1 = 0;
	var s2 = 0;
	for(var k=0; k<testTable.length; k++){
		if(testTable[k] == -1){
			var sum = 0;
			for(var m=1; m<4; m++){
				sum += k-m;
			}
			if(sum == 0){
				testTable[k] = 1;	
			}
			else{
				testTable[k] = 0;
			}
		}
		
		if(testTable[k] == 0){
			responseCompareTable[k] = 0;
			
			testTable[k] = minDelta*0.5;
			s1++;
		}
		else{
			responseCompareTable[k] = 1;
			
			testTable[k] = maxDelta*0.5;
			s2++;
		}
		//post(testTable[k] + " ");
		//post("\n");
		
	}
	
	post("generated random testTable: " + testTable.length + " " + s1 + " " + s2 + "\n");
	
	createTestsStepsTable();
	
}

function createTestsStepsTable(){
	testsStepsTable = new Array();
	for(var i=0; i<testTable.length; i++){
		testsStepsTable[i] = new Array(6);
	}
	
	var m1PosA, m1PosB;
	var m2PosA, m2PosB;
	
	for(var i=0; i<testTable.length; i++){
		var randWaitTime = waitTime + Math.floor((Math.random() - 0.5)*waitTime*0.1);
		testsStepsTable[i][0] = randWaitTime;
		
		if(i==0){
			m1PosA = m1FingerPos + testTable[i]/stepSizeMM;
			m1PosB = m1PosA;
			
			m2PosA = m2FingerPos + testTable[i]/stepSizeMM;
			m2PosB = m2PosA;
		}
		else{
			m1PosA = m1FingerPos + testTable[i-1]/stepSizeMM;
			m1PosB = m1FingerPos + testTable[i]/stepSizeMM;
			
			if(m1PosB >= m1PosA){
				m1PosA = m1PosB + Math.floor((minMovement/stepSizeMM - (m1PosB - m1PosA))/2);
			}
			else{
				m1PosA = m1PosA + Math.floor((minMovement/stepSizeMM - (m1PosA - m1PosB))/2);
			}
			
			m2PosA = m2FingerPos + testTable[i-1]/stepSizeMM;
			m2PosB = m2FingerPos + testTable[i]/stepSizeMM;
			
			if(m2PosB >= m2PosA){
				m2PosA = m2PosB + Math.floor((minMovement/stepSizeMM - (m2PosB - m2PosA))/2);
			}
			else{
				m2PosA = m2PosA + Math.floor((minMovement/stepSizeMM - (m2PosA - m2PosB))/2);
			}
			
		}
		
		testsStepsTable[i][1] = Math.floor(m1PosA);
		testsStepsTable[i][2] = Math.floor(m1PosB);
		testsStepsTable[i][3] = Math.floor(m2PosA);
		testsStepsTable[i][4] = Math.floor(m2PosB);
		testsStepsTable[i][5] = responseCompareTable[i];
		
		/*
		for(var j=0; j<5; j++){
			post(testsStepsTable[i][j] + " ");
		}
		post("\n");
		*/
		
	}
	
	outputDataToColl();
	
}

function outputDataToColl(){
	outlet(1, "bang");
	for(var i=0; i<numTests; i++){
		outlet(0, testsStepsTable[i]);
	}
	
}