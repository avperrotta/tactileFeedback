inlets = 9;
outlets = 8;

setinletassist(0,"experiment control messages");
setinletassist(1,"finger parameters");
setinletassist(2,"motors max pos");
setinletassist(3,"motors course size mm");
setinletassist(4,"experiment times");
setinletassist(5,"active trial list");
setinletassist(6,"passive trial list");
setinletassist(7,"active trial delta");
setinletassist(8,"passive trial delta");



function motor(courseSize, maxPos, fingerPos){
	this.courseSize = courseSize;
	this.maxPos = maxPos;
	this.fingerPos = fingerPos;
	this.stepSizeMM = courseSize/maxPos;

	return this;
}

motor.prototype.setCourseSize = function(val){
	this.courseSize = val;
	this.stepSizeMM = this.courseSize/this.maxPos;
}
motor.prototype.setMaxPos = function(val){
	this.maxPos = val;
	this.stepSizeMM = this.courseSize/this.maxPos;
}
motor.prototype.setFingerPos = function(val){
	this.fingerPos = val;
}

motor.prototype.debug = function(){
	post(this.courseSize);
	post(" ");
	post(this.maxPos);
	post(" ");
	post(this.fingerPos);
	post(" ");
	post(this.stepSizeMM);
	post("\n");
	outlet(0, this.stepSizeMM);
}

function trialEvent(waitTime, probeTime, firstPosM1, secondPosM1, firstPosM2, secondPosM2){

	this.waitTime = waitTime + Math.random()*2*waitTime*0.1 - waitTime*0.1;
	this.probeTime = probeTime;
	this.firstPosM1 = firstPosM1;
	this.secondPosM1 = secondPosM1;
	this.firstPosM2 = firstPosM2;
	this.secondPosM2 = secondPosM2;
	return this;
}



var m1 = new motor(25, 10, 10);
var m2 = new motor(24, 0, 0);

var activeTrialList = new Array();
var passiveTrialList = new Array();
var waitTime;
var probingTime;

var activeTrialEventList = new Array();
var passiveTrialEventList = new Array();

var activeTrialFixedMoveDelta;
var passiveTrialFixedMoveDelta;
var fixedMoveDelta = 6;

function bang(){
	m1.debug();
}

function list(){
	if(inlet == 1){
		if(arguments.length == 3){
			m1.setFingerPos(arguments[0]);
			m2.setFingerPos(arguments[2]);
		}
	}
	else if(inlet == 2){
		if(arguments.length == 2){
			m1.setMaxPos(arguments[0]);
			m2.setMaxPos(arguments[1]);
		}
	}
	else if(inlet == 3){
		if(arguments.length == 2){
			m1.setCourseSize(arguments[0]);
			m2.setCourseSize(arguments[1]);
		}
	}
	else if(inlet == 4){
		if(arguments.length == 2){
			waitTime = arguments[0];
			probingTime = arguments[1];
		}
	}
	else if(inlet == 5){
		if(arguments.length > 0){
			activeTrialList.length = 0;
			activeTrialList[0] = 0;
			for(var i=0; i<arguments.length; i++){
				activeTrialList[i+1] = arguments[i];
			}
			setupActiveTrial();
		}
	}
	else if(inlet == 6){
		if(arguments.length > 0){
			passiveTrialList.length = 0;
			passiveTrialList[0] = 0;
			for(var i=0; i<arguments.length; i++){
				passiveTrialList[i+1] = arguments[i];
			}
		}
	}
	else if(inlet == 7){
		if(arguments.length == 2){
			activeTrialFixedMoveDelta = (arguments[1] - arguments[0])*2;
		}
	}
	else if(inlet == 8){
		if(arguments.length == 2){
			passiveTrialFixedMoveDelta = (arguments[1] - arguments[0])*2;
		}
	}
}

function setupActiveTrial(){

	activeTrialEventList.length = 0;
	for(var i=1; i<activeTrialList.length; i++){
		var delta, m1PosA, m1PosB, m1PosInit, m2PosA, m2PosB, m2PosInit;

		delta = activeTrialList[i]*0.5;

		m1PosA = Math.floor(m1.fingerPos + activeTrialList[i-1]*0.5/m1.stepSizeMM);
		m1PosB = Math.floor(m1.fingerPos + delta/m1.stepSizeMM);

		if(m1PosB >= m1PosA){
			m1PosInit = m1PosB + Math.floor((activeTrialFixedMoveDelta/m1.stepSizeMM - (m1PosB - m1PosA))/2);
		}
		else{
			m1PosInit = m1PosA + Math.floor((activeTrialFixedMoveDelta/m1.stepSizeMM - (m1PosA - m1PosB))/2);
		}

		m2PosA = Math.floor(m2.fingerPos + activeTrialList[i-1]*0.5/m2.stepSizeMM);
		m2PosB = Math.floor(m2.fingerPos + delta/m2.stepSizeMM);

		if(m2PosB >= m2PosA){
			m2PosInit = m2PosB + Math.floor((activeTrialFixedMoveDelta/m2.stepSizeMM - (m2PosB - m2PosA))/2);
		}
		else{
			m2PosInit = m2PosA + Math.floor((activeTrialFixedMoveDelta/m2.stepSizeMM - (m2PosA - m2PosB))/2);
		}


		activeTrialEventList.push(new trialEvent(waitTime, probingTime, m1PosInit, m1PosB, m2PosInit, m2PosB));
		post("\n\n");
		post("m1: " + m1.stepSizeMM + " " + activeTrialList[0] + " " + m1PosA + " " + m1PosB + " " + m1PosInit + "\n");
		post("m2: " + m2.stepSizeMM + " " + activeTrialList[0] + " " + m2PosA + " " + m2PosB + " " + m2PosInit + "\n");
		post("\n\n");
	}
	post(activeTrialList.length + " " + activeTrialEventList.length + "\n");
}

function getActiveTrialEvent(i){
	if(i >= 0 && i < activeTrialEventList.length){
		outlet(0, activeTrialEventList[i].waitTime );
		outlet(1, activeTrialEventList[i].probeTime );
		outlet(2, activeTrialEventList[i].firstPosM1 );
		outlet(3, activeTrialEventList[i].secondPosM1 );
		outlet(4, activeTrialEventList[i].firstPosM2 );
		outlet(5, activeTrialEventList[i].secondPosM2);
		outlet(6, activeTrialList[i+1]);
	}
	else{
		outlet(7, "activeTrialDone");
	}
	
}
